$ErrorActionPreference='Stop'
Write-Host 'Holy Lois: Reborn - Owner Tools'
Write-Host '1 Prepare client release | 2 Server admin | 3 Open owner guide | 0 Exit'
switch (Read-Host 'Choose action') {
    '1' { & (Join-Path $PSScriptRoot 'Prepare-Pack.ps1') }
    '2' { & (Join-Path $PSScriptRoot 'Server-Admin.ps1') }
    '3' { Invoke-Item -LiteralPath (Join-Path (Split-Path $PSScriptRoot -Parent) 'ADMIN-GUIDE.md') }
    '0' {}
    default {throw 'Choose one of the listed actions.'}
}
