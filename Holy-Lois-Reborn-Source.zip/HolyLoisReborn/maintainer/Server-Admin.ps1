param(
    [ValidateSet('menu','status','start','stop','restart','logs','check','update')][string]$Action='menu',
    [string]$Stage=(Join-Path $env:USERPROFILE 'Downloads\server-mods'),
    [string]$Key=(Join-Path $env:USERPROFILE '.ssh\id_ed25519'),
    [string]$HostName=$env:HOLYLOIS_SSH_HOST,
    [string]$User=$env:HOLYLOIS_SSH_USER
)
$ErrorActionPreference='Stop'
if (!$HostName -or !$User) { throw 'Set HOLYLOIS_SSH_HOST and HOLYLOIS_SSH_USER privately, or pass -HostName and -User.' }
if ($HostName -notmatch '^[A-Za-z0-9.-]+$' -or $User -notmatch '^[A-Za-z_][A-Za-z0-9_-]*$') { throw 'Invalid SSH host or user.' }
$destination="${User}@${HostName}"
function Remote([string]$Command) {
    & ssh -i $Key -o BatchMode=yes -o ConnectTimeout=15 $destination $Command
    if ($LASTEXITCODE) {throw "Server command failed with exit code $LASTEXITCODE."}
}
function Update-Mods([bool]$Apply) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $files=@(Get-ChildItem -LiteralPath $Stage -Filter '*.jar' -File)
    if (!$files.Count) {throw 'Place only reviewed 26.3 Fabric SERVER mods and dependencies in the staging folder first.'}
    $records=@();$ids=@{}
    foreach ($file in $files) {
        if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Linked files are not supported.'}
        $zip=[IO.Compression.ZipFile]::OpenRead($file.FullName)
        try {
            $entry=$zip.GetEntry('fabric.mod.json')
            if (!$entry) {throw "Not a Fabric mod: $($file.Name)"}
            $reader=[IO.StreamReader]::new($entry.Open())
            try {$meta=$reader.ReadToEnd() | ConvertFrom-Json} finally {$reader.Dispose()}
        } finally {$zip.Dispose()}
        if ($meta.environment -eq 'client') {throw "Client-only mod in server staging: $($file.Name)"}
        if ($ids.ContainsKey($meta.id)) {throw "Two versions of $($meta.id) are staged."}
        $ids[$meta.id]=$true
        $records+=@{file=$file.Name;mod_id=$meta.id;version=$meta.version;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
    }
    $name='holylois-update-'+[Guid]::NewGuid().ToString('N')
    $local=Join-Path ([IO.Path]::GetTempPath()) $name
    New-Item -ItemType Directory -Path $local | Out-Null
    $manifest=Join-Path $local 'server-update.json'
    [IO.File]::WriteAllText($manifest,(ConvertTo-Json -InputObject @($records) -Depth 8),[Text.UTF8Encoding]::new($false))
    $remote='/home/'+$User+'/'+$name
    Remote "mkdir -m 700 $remote"
    $uploads=@($files.FullName)+@($manifest,(Join-Path $PSScriptRoot 'update-server.py'))
    & scp -i $Key @uploads "${destination}:$remote/"
    if ($LASTEXITCODE) {throw 'Upload failed. Nothing installed.'}
    Remote "sudo python3 $remote/update-server.py $remote check"
    if ($Apply) {Remote "sudo python3 $remote/update-server.py $remote apply"}
    Write-Output "Uploaded stage retained for review: $remote"
}
if ($Action -eq 'menu') {
    Write-Host 'Holy Lois: Reborn - Server Admin'
    Write-Host '1 Status | 2 Start | 3 Stop | 4 Restart | 5 Logs | 6 Check staged mods | 7 Back up and install staged mods | 0 Exit'
    $choice=Read-Host 'Choose action'
    $map=@{'1'='status';'2'='start';'3'='stop';'4'='restart';'5'='logs';'6'='check';'7'='update';'0'='exit'}
    $Action=$map[$choice]
}
switch ($Action) {
    'status' {Remote 'sudo systemctl status minecraft --no-pager -l; df -h /'}
    'start' {Remote 'sudo systemctl start minecraft; sudo systemctl status minecraft --no-pager -l'}
    'stop' {Remote 'sudo systemctl stop minecraft; sudo systemctl is-active minecraft || test $? -eq 3'}
    'restart' {Remote 'sudo systemctl restart minecraft; sudo systemctl status minecraft --no-pager -l'}
    'logs' {Remote 'sudo journalctl -u minecraft -n 100 --no-pager'}
    'check' {Update-Mods $false}
    'update' {Update-Mods $true}
    'exit' {}
    default {throw 'Choose one of the listed actions.'}
}
