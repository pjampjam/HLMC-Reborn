"""Owner-only server mod transaction. Uploaded to Ubuntu by Server-Admin.ps1."""
import pathlib,json,hashlib,zipfile,subprocess,shutil,os,pwd,grp,time,datetime,sys,re
ROOT=pathlib.Path('/opt/minecraft')
BACKUPS=pathlib.Path('/opt/minecraft-backups/maintenance')
def run(*args):
    return subprocess.run(args,check=True,capture_output=True,text=True).stdout
def metadata(path):
    with zipfile.ZipFile(path) as z:
        return json.loads(z.read('fabric.mod.json'),strict=False)
def wait_ready(since):
    for _ in range(120):
        if subprocess.run(['systemctl','is-active','--quiet','minecraft']).returncode==0:
            log=run('journalctl','-u','minecraft','--since',since,'--no-pager','-o','cat')
            if re.search(r'Done \(.+\)! For help, type',log):return
        time.sleep(1)
    raise RuntimeError('Server did not reach Done within 120 seconds.')
stage=pathlib.Path(sys.argv[1]).resolve()
operation=sys.argv[2]
assert os.geteuid()==0 and ROOT.resolve()==ROOT and not ROOT.is_symlink()
assert stage.parent==pathlib.Path(pwd.getpwuid(stage.stat().st_uid).pw_dir) and re.fullmatch(r'holylois-update-[0-9a-f]{32}',stage.name)
assert operation in ['check','apply']
records=json.loads((stage/'server-update.json').read_text())
assert 0<len(records)<=100
incoming_ids=set()
for r in records:
    assert re.fullmatch(r'[A-Za-z0-9_.+ -]+\.jar',r['file'])
    path=stage/r['file'];assert not path.is_symlink() and path.is_file()
    assert hashlib.sha256(path.read_bytes()).hexdigest()==r['sha256']
    m=metadata(path)
    assert m['id']==r['mod_id'] and m['version']==r['version'] and m.get('environment','*')!='client'
    assert m['id'] not in incoming_ids;incoming_ids.add(m['id'])
existing={}
for path in (ROOT/'mods').glob('*.jar'):
    assert not path.is_symlink()
    m=metadata(path);assert m['id'] not in existing, 'Existing duplicate mod: '+m['id']
    existing[m['id']]=path
changes=[r for r in records if r['mod_id'] not in existing or hashlib.sha256(existing[r['mod_id']].read_bytes()).hexdigest()!=r['sha256']]
print(json.dumps({'operation':operation,'changes':[{'mod':r['mod_id'],'version':r['version'],'replaces':existing[r['mod_id']].name if r['mod_id'] in existing else None} for r in changes]}),flush=True)
if operation=='check' or not changes:sys.exit(0)
was_running=subprocess.run(['systemctl','is-active','--quiet','minecraft']).returncode==0
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
BACKUPS.mkdir(mode=0o700,parents=True,exist_ok=True)
backup=BACKUPS/('update-'+stamp);backup.mkdir(mode=0o700)
oldmods=backup/'previous-mods';oldmods.mkdir(mode=0o700)
archive=backup/'complete-server.tar.gz'
installed=[];moved=[]
run('systemctl','stop','minecraft')
try:
    processes=run('ps','-C','java','-o','args=') if subprocess.run(['pgrep','-x','java'],capture_output=True).returncode==0 else ''
    assert not any('server.jar' in line for line in processes.splitlines()), 'Another manual server process remains.'
    # Estimate conservatively using actual byte sizes, not compressed archive size.
    size=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink() and p.relative_to(ROOT).parts[0]!='backups')
    assert shutil.disk_usage(ROOT).free>size+2*1024**3, 'Insufficient space for a stopped full backup and 2 GB reserve.'
    # Scheduled backup archives already have independent retention; do not nest them inside every snapshot.
    run('tar','--exclude=minecraft/backups','-czf',str(archive),'-C','/opt','minecraft')
    run('tar','-tzf',str(archive))
    uid=pwd.getpwnam('minecraft').pw_uid;gid=grp.getgrnam('minecraft').gr_gid
    for r in changes:
        old=existing.get(r['mod_id'])
        if old:shutil.move(str(old),str(oldmods/old.name));moved.append(old.name)
        target=ROOT/'mods'/r['file'];assert not target.exists()
        shutil.copyfile(stage/r['file'],target);os.chown(target,uid,gid);target.chmod(0o644);installed.append(target)
    since=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
    run('systemctl','start','minecraft');wait_ready(since)
    print(json.dumps({'result':'started and Done','backup':str(archive),'mods':len(changes),'world':'preserved'}),flush=True)
except Exception:
    run('systemctl','stop','minecraft')
    for target in installed:
        assert target.parent==ROOT/'mods'
        if target.exists():target.unlink()
    for name in moved:shutil.move(str(oldmods/name),str(ROOT/'mods'/name))
    if was_running:run('systemctl','start','minecraft')
    print('Mod files rolled back. Complete stopped backup retained. Inspect logs before playing.',flush=True)
    raise
# Only these generated maintenance archives are rotated. JEB chains and historical backups are untouched.
archives=sorted(BACKUPS.glob('update-*/complete-server.tar.gz'),key=lambda p:p.stat().st_mtime,reverse=True)
for old in archives[2:]:
    if old.parent.parent==BACKUPS and not old.is_symlink():old.unlink()
(backup/'receipt.json').write_text(json.dumps({'installed':[r['file'] for r in changes],'previous':moved,'backup':str(archive)},indent=2))
