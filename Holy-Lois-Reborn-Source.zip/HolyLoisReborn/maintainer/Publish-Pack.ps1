param([Parameter(Mandatory=$true)][string]$Version,[switch]$Publish,[string]$Gh='gh')
$ErrorActionPreference='Stop'
if ($Version -notmatch '^\d+\.\d+\.\d+$') {throw 'Use a three-part version such as 1.4.1.'}
$root=Split-Path $PSScriptRoot -Parent
$folder=Join-Path $root ('publish\pack-'+$Version)
$files=@('pack.json','pack.json.sig','defaults.zip') | ForEach-Object {Join-Path $folder $_}
foreach ($file in $files) {if (!(Test-Path -LiteralPath $file)) {throw 'Prepare and test this pack first.'}}
$manifest=Get-Content -LiteralPath $files[0] -Raw | ConvertFrom-Json
if ($manifest.version -ne $Version) {throw 'Manifest version does not match.'}
$expected='https://github.com/pjampjam/HLMC-Reborn/releases/download/pack-v'+$Version+'/defaults.zip'
if ($manifest.defaults.url -ne $expected) {throw 'Defaults must use this immutable release tag.'}
if ((Get-FileHash -LiteralPath $files[2] -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.defaults.sha256) {throw 'Defaults hash mismatch.'}
Write-Host "Publish defaults to pack-v$Version, then promote the manifest and signature to pack-stable."
if (!$Publish) {Write-Host 'Preview only. After testing, add -Publish. Requires official GitHub CLI and your own gh auth login.';return}
& $Gh auth status
if ($LASTEXITCODE) {throw 'Sign in to GitHub CLI yourself with gh auth login, then retry. Never paste a token into the script.'}
& $Gh release view "pack-v$Version" --repo pjampjam/HLMC-Reborn *> $null
if (!$LASTEXITCODE) {throw 'This immutable version already exists. Choose a new version.'}
& $Gh release create "pack-v$Version" $files[2] --repo pjampjam/HLMC-Reborn --title "Holy Lois: Reborn - Pack $Version" --notes "Tested client pack $Version. Author downloads are described in the signed stable feed." --latest=false
if ($LASTEXITCODE) {throw 'Immutable release failed. Stable feed unchanged.'}
& $Gh release upload pack-stable $files[0] $files[1] --repo pjampjam/HLMC-Reborn --clobber
if ($LASTEXITCODE) {throw 'Stable feed promotion failed. Re-upload the matching manifest and signature together.'}
Write-Host 'Published. Open Holy Lois and verify the new version. Friends see it on the next update check.'
