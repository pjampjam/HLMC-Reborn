param(
    [Parameter(Mandatory=$true)][string]$AppExe,
    [Parameter(Mandatory=$true)][string]$SetupExe,
    [switch]$RequireTrustedPublisher
)
$ErrorActionPreference = 'Stop'
$started = Get-Date
$status = Get-MpComputerStatus
if (!$status.AntivirusEnabled -or !$status.RealTimeProtectionEnabled -or $status.AMRunningMode -ne 'Normal') {
    throw 'Microsoft Defender must be active for this release check. No protection settings were changed.'
}
$preferences = Get-MpPreference
if (@($preferences.ThreatIDDefaultAction_Actions | Where-Object { [int]$_ -in @(6,9,11) }).Count) {
    throw 'Defender has an explicit non-remediating threat action. A scan under an Allow/NoAction/None rule cannot validate this release. Review allowed threats manually; this check will not change protection settings.'
}
$files = @([IO.Path]::GetFullPath($AppExe), [IO.Path]::GetFullPath($SetupExe))
$records = @()
foreach ($file in $files) {
    if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw "Release artifact missing, possibly quarantined: $file" }
    Start-MpScan -ScanType CustomScan -ScanPath $file
    # Scan success alone is insufficient: Defender can quarantine a detected artifact.
    if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw "Defender removed an artifact. Release blocked: $file" }
    $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    $signature = Get-AuthenticodeSignature -LiteralPath $file
    if ($RequireTrustedPublisher -and $signature.Status -ne 'Valid') { throw "A trusted Authenticode signature is required: $file" }
    $records += @{ file = [IO.Path]::GetFileName($file); sha256 = $hash; authenticode = [string]$signature.Status }
}
$detections = @(Get-MpThreatDetection | Where-Object {
    $detection = $_
    ($detection.InitialDetectionTime -ge $started -or $detection.LastThreatStatusChangeTime -ge $started) -and
    @($files | Where-Object { $path = $_; @($detection.Resources | Where-Object { $_.IndexOf($path,[StringComparison]::OrdinalIgnoreCase) -ge 0 }).Count -gt 0 }).Count -gt 0
})
if ($detections.Count) { throw 'Defender reported a release-artifact detection. Distribution stays blocked pending review.' }
$receipt = @{ scanned = (Get-Date).ToUniversalTime().ToString('o'); definitions = $status.AntivirusSignatureVersion; artifacts = $records; limits = 'Bounded local scan only. Does not guarantee all engines/cloud heuristics are clear. Browser-download testing and publisher review remain necessary.' }
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($files[0] + '.defender-check.json') -Encoding utf8
Write-Output 'Local Defender release check passed. Keep browser-download verification and trusted publisher signing in the release workflow.'
