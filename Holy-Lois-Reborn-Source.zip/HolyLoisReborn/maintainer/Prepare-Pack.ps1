param([string]$Profile = (Join-Path $env:USERPROFILE 'curseforge\minecraft\Instances\Holy Lois Reborn'), [string]$Version)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
if (!$Version) { $Version = Read-Host 'New pack version, for example 1.4.2' }
if (Get-Process java,javaw -ErrorAction SilentlyContinue) { throw 'Close Minecraft before preparing a release.' }
$key = Join-Path $root 'private\release-private.pem'
if (!(Test-Path -LiteralPath $key)) { throw 'Private publishing key missing. Keep it private and never upload it.' }
$sdk = Join-Path $root '..\toolchain\dotnet\dotnet.exe'
if (!(Test-Path -LiteralPath $sdk)) { $sdk = 'dotnet' }
$base = Join-Path $root 'assets\pack.json'
$output = Join-Path $root ('publish\pack-' + $Version)
if (Test-Path -LiteralPath $output) { throw 'That output folder already exists. Review it before retrying.' }
$publisher = Join-Path $root 'src\HolyLois.Publisher\bin\Release\net10.0\HolyLois.Publisher.dll'
if (!(Test-Path -LiteralPath $publisher)) {
    & $sdk build (Join-Path $root 'src\HolyLois.Publisher') -c Release
    if ($LASTEXITCODE) { throw 'Publisher build failed.' }
}
& $sdk $publisher prepare-pack $key $base $Profile $Version (Join-Path $root 'assets\defaults.zip') $output
if ($LASTEXITCODE) { throw 'Pack preparation failed. Review the reported file or dependency.' }
Write-Output "Prepared release: $output"
Write-Output "Uses the reviewed shared defaults. To change them, review assets/defaults.zip first. Test before publishing. Upload defaults.zip to pack-v$Version, then promote pack.json and pack.json.sig together in pack-stable. Keep the launcher release marked Latest."
