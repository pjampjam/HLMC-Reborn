@echo off
if exist "%LOCALAPPDATA%\HolyLoisReborn\HolyLoisSetup.exe" (
  "%LOCALAPPDATA%\HolyLoisReborn\HolyLoisSetup.exe" --owner-root "%~dp0."
) else (
  "%~dp0publish\public-release-0.4.0\HolyLoisReborn.exe" --owner-root "%~dp0."
)
