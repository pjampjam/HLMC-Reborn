@echo off
"%~dp0publish\public-release-0.3.0\HolyLoisReborn.exe" --owner-root "%~dp0."
