using HolyLois.Core;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;

namespace HolyLois.App;

public static class LauncherStartup
{
    public static string InstallRoot => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HolyLoisReborn");

    // The checker is inside the signed application. Updating the application updates its checker too.
    public static async Task<string> InstallCheckerAsync(string root)
    {
        var checker = SafePaths.Resolve(root, "HolyLoisSetup.exe");
        var bytes = ClientContext.Asset("HolyLoisSetup.exe");
        Directory.CreateDirectory(root);
        if (File.Exists(checker) && new FileInfo(checker).Length == bytes.Length &&
            CryptographicOperations.FixedTimeEquals(SHA256.HashData(await File.ReadAllBytesAsync(checker)), SHA256.HashData(bytes))) return checker;
        var staged = SafePaths.Resolve(root, "HolyLoisSetup.exe.next");
        await File.WriteAllBytesAsync(staged, bytes);
        try
        {
            // The previous checker exits just after starting us, releasing its executable lock.
            for (var attempt = 0; ; attempt++)
            {
                try { File.Move(staged, checker, true); break; }
                catch (IOException) when (attempt < 50) { await Task.Delay(100); }
                catch (UnauthorizedAccessException) when (attempt < 50) { await Task.Delay(100); }
            }
        }
        finally { if (File.Exists(staged)) File.Delete(staged); }
        return checker;
    }

    public static void RunChecker(string checker, string[] arguments)
    {
        var start = new ProcessStartInfo(checker) { UseShellExecute = false, WorkingDirectory = Path.GetDirectoryName(checker)! };
        foreach (var argument in arguments.Where(a => a != "--app-verified")) start.ArgumentList.Add(argument);
        Process.Start(start)?.Dispose();
    }

    public static void CreateShortcut(string root, bool desktop)
    {
        var folder = Environment.GetFolderPath(desktop ? Environment.SpecialFolder.DesktopDirectory : Environment.SpecialFolder.Programs);
        var shortcut = SafePaths.Resolve(folder, "Holy Lois Reborn.lnk");
        // A personalized existing link belongs to the player.
        if (File.Exists(shortcut)) return;
        var target = SafePaths.Resolve(root, "HolyLoisSetup.exe");
        var shellType = Type.GetTypeFromProgID("WScript.Shell") ?? throw new IOException("Windows shortcuts are unavailable.");
        dynamic shell = Activator.CreateInstance(shellType)!;
        try
        {
            dynamic link = shell.CreateShortcut(shortcut);
            try { link.TargetPath = target; link.IconLocation = target + ",0"; link.WorkingDirectory = root; link.Description = "Holy Lois: Reborn - update and play"; link.Save(); }
            finally { System.Runtime.InteropServices.Marshal.FinalReleaseComObject(link); }
        }
        finally { System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell); }
    }
}
