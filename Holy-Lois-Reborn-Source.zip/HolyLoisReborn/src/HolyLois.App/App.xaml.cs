using System.IO;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace HolyLois.App;

public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            var args = e.Args;
            string? data = null;
            var index = Array.IndexOf(args, "--data-dir");
            if (index >= 0 && args.Length > index + 1) data = Path.GetFullPath(args[index + 1]);
            if (data is null && Assembly.GetExecutingAssembly().GetCustomAttributes<AssemblyMetadataAttribute>().Any(a => a.Key == "HolyLoisPreview" && a.Value == "true"))
                data = Path.Combine(AppContext.BaseDirectory, "preview-data");
            string? launcherTestRoot = null;
            var launcherIndex = Array.IndexOf(args, "--launcher-test-root");
            if (launcherIndex >= 0)
            {
                if (index < 0 || launcherIndex + 1 >= args.Length || args.Contains("--render-preview"))
                    throw new ArgumentException("Launcher integration tests require an explicit --data-dir and launcher library path.");
                launcherTestRoot = Path.GetFullPath(args[launcherIndex + 1]);
            }
            var context = new ClientContext(data, launcherTestRoot);
            if (args.Contains("--render-preview"))
            {
                if (data is null) throw new ArgumentException("Rendering requires an isolated --data-dir.");
                context.SelectLauncher("official");
                var window = new MainWindow(context);
                Render(window, data, "launcher-design.png", 1020, 708);
                Render(window, data, "launcher-design-small.png", 900, 588);
                context.SelectLauncher("sk");
                window = new MainWindow(context);
                Render(window, data, "launcher-design-sk.png", 1020, 708);
                Shutdown(0); return;
            }
            if (args.Contains("--verify-install"))
            {
                if (data is null) throw new ArgumentException("Verification requires an explicit isolated --data-dir.");
                var skIndex = Array.IndexOf(args, "--link-sk-instance");
                if (skIndex >= 0)
                {
                    if (launcherTestRoot is null || skIndex + 1 >= args.Length) throw new ArgumentException("Linked verification requires a launcher integration root.");
                    context.SelectLauncher("sk");
                    context.LinkSkInstance(args[skIndex + 1]);
                }
                if (args.Contains("--check-online")) await context.CheckUpdatesAsync(CancellationToken.None);
                await context.InstallAsync(null, CancellationToken.None);
                File.WriteAllText(Path.Combine(data, "verification-result.txt"), "Verified downloads, installed pack, server list and Fabric profile. Pack " + context.Manifest.Version);
                Shutdown(0); return;
            }
            MainWindow = new MainWindow(context); MainWindow.Show();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Holy Lois: Reborn - setup could not start", MessageBoxButton.OK, MessageBoxImage.Warning);
            Shutdown(1);
        }
    }
    private static void Render(MainWindow window, string root, string name, int width, int height)
    {
        var content = (FrameworkElement)window.Content;
        content.Measure(new Size(width, height)); content.Arrange(new Rect(0, 0, width, height)); content.UpdateLayout();
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
        var background = new DrawingVisual();
        using (var drawing = background.RenderOpen()) drawing.DrawRectangle(window.Background, null, new Rect(0, 0, width, height));
        bitmap.Render(background); bitmap.Render(content);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var file = File.Create(Path.Combine(root, name)); encoder.Save(file);
    }
}
