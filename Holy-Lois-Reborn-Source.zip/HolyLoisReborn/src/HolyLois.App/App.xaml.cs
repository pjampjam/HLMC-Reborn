using System.IO;
using HolyLois.Core;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace HolyLois.App;

public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            var args = e.Args;
            var development = args.Contains("--data-dir") || args.Any(a => a.StartsWith("--render-", StringComparison.Ordinal) || a.StartsWith("--verify-", StringComparison.Ordinal)) || args.Contains("--publish-prepared");
            if (!development)
            {
                var checker = await LauncherStartup.InstallCheckerAsync(LauncherStartup.InstallRoot);
                if (!args.Contains("--app-verified")) { LauncherStartup.RunChecker(checker, args); Shutdown(0); return; }
            }
            var ownerIndex = Array.IndexOf(args, "--owner-root");
            if (ownerIndex >= 0 && ownerIndex + 1 < args.Length) {
                var preparedIndex = Array.IndexOf(args, "--publish-prepared");
                if (preparedIndex >= 0 && preparedIndex + 1 < args.Length) {
                    var published=await OwnerPublishing.PublishAsync(args[ownerIndex+1],args[preparedIndex+1]);
                    File.WriteAllText(Path.Combine(args[preparedIndex+1],"publish-result.txt"),"Published pack "+published+" through the owner app publishing service.");
                    Shutdown(0);return;
                }
                MainWindow = new OwnerWindow(args[ownerIndex + 1]);
                if (args.Contains("--render-owner-preview")) { Render(MainWindow, args[ownerIndex + 1], "owner-preview.png", 820, 820); Shutdown(0); }
                else MainWindow.Show(); return;
            }
            string? data = null;
            var index = Array.IndexOf(args, "--data-dir");
            if (index >= 0 && args.Length > index + 1) data = Path.GetFullPath(args[index + 1]);
            if (data is null && Assembly.GetExecutingAssembly().GetCustomAttributes<AssemblyMetadataAttribute>().Any(a => a.Key == "HolyLoisPreview" && a.Value == "true"))
                data = Path.Combine(AppContext.BaseDirectory, "preview-data");
            string? launcherTestRoot = null;
            var launcherIndex = Array.IndexOf(args, "--launcher-test-root");
            if (launcherIndex >= 0)
            {
                if (index < 0 || launcherIndex + 1 >= args.Length || args.Contains("--render-preview"))
                    throw new ArgumentException("Launcher integration tests require an explicit --data-dir and launcher library path.");
                launcherTestRoot = Path.GetFullPath(args[launcherIndex + 1]);
            }
            var context = new ClientContext(data, launcherTestRoot);
            if (args.Contains("--verify-checker")) {
                if (data is null || !context.IsIsolated) throw new ArgumentException("Checker verification requires an isolated folder.");
                var checker = await LauncherStartup.InstallCheckerAsync(data);
                var first = System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(checker));
                await LauncherStartup.InstallCheckerAsync(data);
                if (!first.SequenceEqual(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(checker)))) throw new InvalidDataException("Checker repair changed approved bytes.");
                File.WriteAllText(Path.Combine(data,"checker-result.txt"), "Embedded checker installed and repeated without shortcut creation."); Shutdown(0); return;
            }
            if (args.Contains("--render-setup-preview")) {
                if (data is null) throw new ArgumentException("Rendering requires an isolated folder.");
                foreach (var language in new[] { "en", "ru", "lv" }) { context.SetLanguage(language); var setup = new SetupWindow(context, data); Render(setup,data,"setup-"+language+".png",764,721); }
                Shutdown(0); return;
            }
            if (args.Contains("--verify-recovery")) {
                if (data is null || !context.IsIsolated) throw new ArgumentException("Recovery test requires an isolated folder.");
                File.WriteAllText(Path.Combine(data,"launcher-settings.json"), "{\"launcher\":\"sk\",\"skInstance\":" + System.Text.Json.JsonSerializer.Serialize(Path.Combine(data,"deleted-sk-instance")) + "}");
                context = new ClientContext(data);
                if (context.Settings.SkInstance is not null || !context.RecoveredDeletedInstance || context.CanPlay) throw new InvalidDataException("Deleted instance recovery failed.");
                await LauncherDiscovery.WarmAsync();
                File.WriteAllText(Path.Combine(data,"recovery-result.txt"), "Deleted SK link reset without a startup failure. Official launcher: " + LauncherDiscovery.Registered("official"));
                Shutdown(0); return;
            }
            if (args.Contains("--render-preview"))
            {
                if (data is null) throw new ArgumentException("Rendering requires an isolated --data-dir.");
                await LauncherDiscovery.WarmAsync();
                context.SelectLauncher("official");
                var window = new MainWindow(context);
                Render(window, data, "launcher-design.png", 1060, 748);
                Render(window, data, "launcher-design-small.png", 900, 588);
                context.SelectLauncher("sk");
                window = new MainWindow(context);
                Render(window, data, "launcher-design-sk.png", 1020, 708);
                context.SetLanguage("ru"); window = new MainWindow(context); Render(window,data,"launcher-design-ru.png",1060,748);
                context.SetLanguage("lv"); window = new MainWindow(context); Render(window,data,"launcher-design-lv.png",1060,748);
                Shutdown(0); return;
            }
            if (args.Contains("--verify-install"))
            {
                if (data is null) throw new ArgumentException("Verification requires an explicit isolated --data-dir.");
                var skIndex = Array.IndexOf(args, "--link-sk-instance");
                if (skIndex >= 0)
                {
                    if (launcherTestRoot is null || skIndex + 1 >= args.Length) throw new ArgumentException("Linked verification requires a launcher integration root.");
                    context.SelectLauncher("sk");
                    context.LinkSkInstance(args[skIndex + 1]);
                }
                if (args.Contains("--check-online")) await context.CheckUpdatesAsync(CancellationToken.None);
                await context.InstallAsync(null, CancellationToken.None);
                File.WriteAllText(Path.Combine(data, "verification-result.txt"), "Verified downloads, installed pack, server list and Fabric profile. Pack " + context.Manifest.Version);
                Shutdown(0); return;
            }
            if (!context.IsIsolated)
            {
                var root = LauncherStartup.InstallRoot;
                if (LauncherSetup.NeedsSetup(root, File.Exists(Path.Combine(context.Root,"launcher-settings.json"))))
                {
                    ShutdownMode = ShutdownMode.OnExplicitShutdown;
                    var setup = new SetupWindow(context,root); setup.ShowDialog();
                    if (!setup.Completed) { Shutdown(0); return; }
                }
                else LauncherSetup.Migrate(root,context.Settings.Launcher);
            }
            MainWindow = new MainWindow(context); MainWindow.Show(); ShutdownMode = ShutdownMode.OnLastWindowClose;
        }
        catch (Exception ex)
        {
            if (e.Args.Any(a => a.StartsWith("--verify-", StringComparison.Ordinal)) || e.Args.Contains("--publish-prepared"))
            {
                var dataIndex = Array.IndexOf(e.Args, "--data-dir");
                if (dataIndex >= 0 && dataIndex + 1 < e.Args.Length)
                    File.WriteAllText(Path.Combine(e.Args[dataIndex + 1], "verification-error.txt"), ex.ToString());
                var preparedIndex=Array.IndexOf(e.Args,"--publish-prepared");
                if(preparedIndex>=0 && preparedIndex+1<e.Args.Length) File.WriteAllText(Path.Combine(e.Args[preparedIndex+1],"publish-error.txt"),ex.Message);
                Shutdown(1); return;
            }
            MessageBox.Show(ex.Message, "Holy Lois: Reborn - setup could not start", MessageBoxButton.OK, MessageBoxImage.Warning);
            Shutdown(1);
        }
    }
    private static void Render(Window window, string root, string name, int width, int height)
    {
        var content = (FrameworkElement)window.Content;
        content.Measure(new Size(width, height)); content.Arrange(new Rect(0, 0, width, height)); content.UpdateLayout();
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
        var background = new DrawingVisual();
        using (var drawing = background.RenderOpen()) drawing.DrawRectangle(window.Background, null, new Rect(0, 0, width, height));
        bitmap.Render(background); bitmap.Render(content);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var file = File.Create(Path.Combine(root, name)); encoder.Save(file);
    }
}
