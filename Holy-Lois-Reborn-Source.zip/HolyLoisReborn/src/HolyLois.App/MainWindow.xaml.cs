using HolyLois.Core;
using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using System.Reflection;

namespace HolyLois.App;

public partial class MainWindow : Window
{
    private readonly ClientContext context;
    private CancellationTokenSource? cancellation;
    private readonly DispatcherTimer updateTimer = new() { Interval = TimeSpan.FromMinutes(2) };
    private bool checking;
    public MainWindow(ClientContext context)
    {
        this.context = context; InitializeComponent(); Closing += OnClosing;
        SourceInitialized += (_, _) => WindowCaption.Apply(this);
        var preview = Assembly.GetExecutingAssembly().GetCustomAttributes<AssemblyMetadataAttribute>().Any(a => a.Key == "HolyLoisPreview" && a.Value == "true");
        AppVersion.Text = (preview ? "Development preview " : "Launcher ") + "0.2.0";
        if (!context.IsIsolated)
        {
            Loaded += async (_, _) => { await CheckUpdates(); updateTimer.Start(); };
            updateTimer.Tick += async (_, _) => await CheckUpdates();
        }
        Closed += (_, _) => updateTimer.Stop();
        ReleaseLabel.Text = "Minecraft 26.3  /  Fabric 0.19.5  /  Pack " + context.Manifest.Version;
        SizeLabel.Text = $"{context.Manifest.Files.Count(f => f.Path.StartsWith("mods/"))} mods · {context.Manifest.Files.Sum(f => f.Size) / 1048576:N0} MB";
        if (context.IsIsolated) StatusText.Text = "This preview installs into its own folder. Your current Minecraft profiles stay separate.";
        Refresh();
    }
    private void Refresh()
    {
        var sk = context.Settings.Launcher == "sk";
        ReleaseLabel.Text = "Minecraft 26.3  /  Fabric 0.19.5  /  Pack " + context.Manifest.Version;
        SizeLabel.Text = $"{context.Manifest.Files.Count(f => f.Path.StartsWith("mods/"))} mods · {context.Manifest.Files.Sum(f => f.Size) / 1048576:N0} MB";
        OfficialSelected.Visibility = sk ? Visibility.Hidden : Visibility.Visible; SkSelected.Visibility = sk ? Visibility.Visible : Visibility.Hidden;
        var neutral = new SolidColorBrush(Color.FromRgb(132, 134, 122)); var accent = (Brush)FindResource("Gold");
        OfficialCard.BorderBrush = sk ? neutral : accent;
        SkCard.BorderBrush = sk ? accent : neutral;
        LinkSkButton.Visibility = sk ? Visibility.Visible : Visibility.Collapsed;
        LauncherHint.Text = sk && context.Settings.SkInstance is null
            ? "After installing the pack, import Holy Lois from the Official launcher in SKlauncher's Library. Link the imported game folder here for future updates."
            : sk ? "Your SKlauncher instance is linked. Select Holy Lois: Reborn in SKlauncher to play."
            : "Select Holy Lois: Reborn under Installations in Minecraft Launcher. Sign in there with your Microsoft account.";
        var receipt = context.Receipt;
        var available = receipt is not null && receipt.Version != context.Manifest.Version;
        PackStatus.Text = receipt is null ? "Pack not installed" : available ? "Pack " + context.Manifest.Version + " available" : context.CanPlay ? "Pack " + receipt.Version + " installed" : "Finish launcher setup";
        InstallLabel.Text = receipt is null ? "Install Holy Lois" : available ? "Update Holy Lois" : context.CanPlay ? "Verify & update" : "Finish setup";
        PlayButton.IsEnabled = context.CanPlay && cancellation is null;
        var ready = context.CanPlay;
        InstallButton.Background = ready ? new SolidColorBrush(Color.FromRgb(41, 42, 38)) : accent;
        InstallLabel.Foreground = ready ? new SolidColorBrush(Color.FromRgb(243, 243, 238)) : new SolidColorBrush(Color.FromRgb(17, 18, 15));
        InstallButton.BorderThickness = ready ? new Thickness(1) : new Thickness(0);
        PlayButton.Background = ready ? accent : new SolidColorBrush(Color.FromRgb(41, 42, 38));
        PlayLabel.Foreground = ready ? new SolidColorBrush(Color.FromRgb(17, 18, 15)) : new SolidColorBrush(Color.FromRgb(243, 243, 238));
        PlayLabel.Text = sk ? "Open SKlauncher" : "Open Minecraft Launcher";
    }
    private void Official_Click(object sender, RoutedEventArgs e) { context.SelectLauncher("official"); Refresh(); }
    private void Sk_Click(object sender, RoutedEventArgs e) { context.SelectLauncher("sk"); Refresh(); }
    private async void CheckUpdates_Click(object sender, RoutedEventArgs e) => await CheckUpdates();
    private async Task CheckUpdates()
    {
        if (checking || cancellation is not null) return;
        checking = true; CheckUpdatesButton.IsEnabled = false;
        try
        {
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(25));
            var changed = await context.CheckUpdatesAsync(timeout.Token);
            Refresh();
            UpdateStatus.Text = changed || context.Receipt is { } receipt && receipt.Version != context.Manifest.Version
                ? "A new pack is ready. Close Minecraft, then update here." : "Latest signed pack checked.";
        }
        catch (Exception ex) when (ex is System.Net.Http.HttpRequestException or OperationCanceledException)
        { UpdateStatus.Text = "Online check unavailable. Using the last verified release."; }
        catch (Exception)
        { UpdateStatus.Text = "Release check failed verification. Your installed pack was kept."; }
        finally { checking = false; CheckUpdatesButton.IsEnabled = cancellation is null; }
    }
    private async void Install_Click(object sender, RoutedEventArgs e)
    {
        cancellation = new(); SetBusy(true);
        try
        {
            if (checking) throw new IOException("Wait for the release check to finish, then try again.");
            if (!context.IsIsolated)
            {
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellation.Token);
                timeout.CancelAfter(TimeSpan.FromSeconds(25));
                try { await context.CheckUpdatesAsync(timeout.Token); }
                catch (System.Net.Http.HttpRequestException) { UpdateStatus.Text = "Using the last verified release while offline."; }
                catch (OperationCanceledException) when (!cancellation.IsCancellationRequested) { UpdateStatus.Text = "Using the last verified release while offline."; }
            }
            await context.InstallAsync(new Progress<InstallProgress>(p => {
                StatusText.Text = p.Message; Progress.Value = p.TotalBytes == 0 ? 0 : 100.0 * p.CompletedBytes / p.TotalBytes;
            }), cancellation.Token);
            Refresh(); StatusText.Text = "Installed and verified. Holy Lois is already listed in Multiplayer."; Progress.Value = 100;
        }
        catch (OperationCanceledException) { StatusText.Text = "Download cancelled. Run Verify & update before playing."; }
        catch (Exception ex) { StatusText.Text = ex.Message; }
        finally { cancellation.Dispose(); cancellation = null; SetBusy(false); Refresh(); }
    }
    private void SetBusy(bool busy)
    { InstallButton.IsEnabled = OfficialCard.IsEnabled = SkCard.IsEnabled = !busy; CheckUpdatesButton.IsEnabled = !busy && !checking; PlayButton.IsEnabled = !busy && context.CanPlay; CancelButton.Visibility = busy ? Visibility.Visible : Visibility.Collapsed; }
    private void Cancel_Click(object sender, RoutedEventArgs e) => cancellation?.Cancel();
    private void Play_Click(object sender, RoutedEventArgs e)
    { try { context.OpenLauncher(); StatusText.Text = "Select Holy Lois: Reborn in your launcher, then Play."; } catch (Exception ex) { StatusText.Text = ex.Message; } }
    private void Locate_Click(object sender, RoutedEventArgs e)
    {
        if (cancellation is not null) return;
        var dialog = new OpenFileDialog { Title = "Choose your installed Minecraft launcher", Filter = "Launcher executable (*.exe)|*.exe", CheckFileExists = true };
        if (dialog.ShowDialog(this) == true) { context.SetLauncher(dialog.FileName); StatusText.Text = "Launcher location saved."; }
    }
    private void LinkSk_Click(object sender, RoutedEventArgs e)
    {
        if (cancellation is not null) return;
        var dialog = new OpenFolderDialog { Title = "Choose the imported Holy Lois instance game folder" };
        if (dialog.ShowDialog(this) == true)
            try { context.LinkSkInstance(dialog.FolderName); Refresh(); StatusText.Text = "Instance linked. Run Verify & update before playing."; }
            catch (Exception ex) { StatusText.Text = ex.Message; }
    }
    private void GetLauncher_Click(object sender, RoutedEventArgs e) => ClientContext.OpenUrl(context.Settings.Launcher == "sk" ? "https://next.skmedix.pl/downloads" : "https://www.minecraft.net/download");
    private void GameFolder_Click(object sender, RoutedEventArgs e)
    {
        Directory.CreateDirectory(context.Instance);
        Process.Start(new ProcessStartInfo("explorer.exe") { UseShellExecute = true, ArgumentList = { context.Instance } });
    }
    private void CopyAddress_Click(object sender, RoutedEventArgs e) { Clipboard.SetText(context.Manifest.Server); StatusText.Text = "Server address copied: " + context.Manifest.Server; }
    private void DisableShaders_Click(object sender, RoutedEventArgs e)
    {
        if (cancellation is not null) return;
        try { context.DisableShaders(); StatusText.Text = "Shaders disabled. Other graphics settings were kept."; }
        catch (Exception ex) { StatusText.Text = ex.Message; }
    }
    private void Help_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(this, "1. Close Minecraft and choose your launcher.\n2. Install Holy Lois.\n3. Select Holy Lois: Reborn in that launcher and play.\n4. Multiplayer already includes the server.\n\nSKlauncher 4: import the prepared official profile once, then link the imported game folder here for updates.\n\nIn-game: V opens microphone setup. /tpa NAME, /home set base and /rtp help you get started. Offline accounts register a password on the server. Never enter that password in this app.", "Welcome to Holy Lois: Reborn", MessageBoxButton.OK, MessageBoxImage.Information);
    }
    private void OnClosing(object? sender, CancelEventArgs e)
    { if (cancellation is not null) { e.Cancel = true; cancellation.Cancel(); StatusText.Text = "Cancelling downloads safely… close again when finished."; } }
}
