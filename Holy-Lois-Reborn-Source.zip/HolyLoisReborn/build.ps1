param([switch]$Publish, [switch]$Public, [string]$PublishFolder = 'publish\app')
$ErrorActionPreference = 'Stop'
if ($Public -and $Publish -and (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'SECURITY-NOTICE.md'))) {
    throw 'Public launcher distribution is on hold. Obtain the final Microsoft determination, review the affected source/artifacts, and explicitly retire the security hold before publishing.'
}
$env:DOTNET_CLI_HOME = Join-Path $PSScriptRoot '..\dotnet-home'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_GENERATE_ASPNET_CERTIFICATE = 'false'
$env:NUGET_PACKAGES = Join-Path $PSScriptRoot '..\nuget'
$sdk = Join-Path $PSScriptRoot '..\toolchain\dotnet\dotnet.exe'
if (!(Test-Path -LiteralPath $sdk)) { $sdk = 'dotnet' }
& (Join-Path $PSScriptRoot 'bootstrap/build-bootstrap.ps1') -CatalogUrl 'https://github.com/pjampjam/HLMC-Reborn/releases/latest/download/app-release.txt'
$projects = @('HolyLois.Core','HolyLois.Tests','HolyLois.App','HolyLois.Publisher')
foreach ($project in $projects) {
    $path = Join-Path $PSScriptRoot "src\$project\$project.csproj"
    if (!(Test-Path -LiteralPath $path)) { continue }
    & $sdk restore $path --configfile (Join-Path $PSScriptRoot 'NuGet.Config')
    if ($LASTEXITCODE) { throw "Restore failed: $project" }
    & $sdk build $path -c Release --no-restore --nologo
    if ($LASTEXITCODE) { throw "Build failed: $project" }
}
& $sdk run --project (Join-Path $PSScriptRoot 'src\HolyLois.Tests') -c Release --no-build
if ($LASTEXITCODE) { throw 'Updater tests failed.' }
if ($Publish) {
    $preview = if ($Public) { 'false' } else { 'true' }
    & $sdk publish (Join-Path $PSScriptRoot 'src\HolyLois.App') -c Release -r win-x64 --self-contained true -p:HolyLoisPreview=$preview -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishReadyToRun=false -p:EnableCompressionInSingleFile=true --configfile (Join-Path $PSScriptRoot 'NuGet.Config') -o (Join-Path $PSScriptRoot $PublishFolder)
    if ($LASTEXITCODE) { throw 'App publishing failed.' }
    if ($Public) {
        & (Join-Path $PSScriptRoot 'maintainer/Check-Windows-Release.ps1') -AppExe (Join-Path $PSScriptRoot "$PublishFolder/HolyLoisReborn.exe") -SetupExe (Join-Path $PSScriptRoot 'publish/bootstrap/HolyLoisSetup.exe')
    }
}
