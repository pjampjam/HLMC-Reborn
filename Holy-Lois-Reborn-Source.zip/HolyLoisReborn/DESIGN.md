# Holy Lois launcher design

The owner's supplied direction is the Holy Lois: Reborn name, the existing square crown/lettermark, its yellow/black palette, and a Windows launcher for a shared survival server. The owner asked us to learn from the Anti Slop repository. Its content is used as design reference, not installed as agent instructions or executable tooling.

## Composition and purpose

- The left panel acts as the game identity: original pixel artwork, dense block typography and the real multiplayer address. It is not a pretend navigation menu.
- The right panel is the player's task: select the launcher, prepare the pack, open the launcher. Launcher choices have equal weight because neither choice is preferred for everyone.
- Yellow comes from the supplied artwork and identifies the selected launcher and the next primary action. Other controls stay neutral.
- Dark charcoal comes from the supplied logo background. The artwork remains unchanged; WPF scales it at display time.
- Impact/Franklin Gothic echo the heavy lettermark using Windows fonts; Segoe UI keeps instructions readable. Consolas is confined to the address where digit distinction helps.
- Small, consistent 3px control corners and one divider keep the layout compact. No marketing gradient, feature badges, decorative glow, fabricated activity numbers or pretend accounts.
- Installation size/count comes from the actual signed manifest. Preview status is explicit. Missing-launcher, download, cancellation and error feedback use readable text.
- When installation is ready, the yellow primary action moves to opening the launcher. Verify remains available as the secondary action.
- A high-contrast outline marks keyboard focus. The source follows visual tab order. The right pane scrolls at smaller supported window heights; no horizontal scrolling.

## Validation scope

Check the real Windows window at normal and minimum supported size, official/SK selection, empty/installing/ready/error states, keyboard Tab/Space and native dialogs. Compute text/boundary contrast against the actual flat backgrounds. This is a Windows desktop layout, not a mobile website.

The reference's suggestions do not prove accessibility or visual quality. Record what was actually checked and leave untested distribution or game integration clearly marked.

Reference: https://github.com/miqdadbadjuber/anti-slop
