# Holy Lois Login

Client-only Minecraft 26.3 / Fabric 0.19.5 / Java 25 source. Entry point: `holylois.auth.HolyLoisAuthClient`. Compile all production Java files against the Minecraft/Fabric classpath; exclude AuthPolicyTest from the release JAR. The paired server onboarding addon owns authentication state; EasyAuth owns credentials. MIT license. See TEST-GUIDE.md and TECHNICAL-GUIDE.md.
