#define CATALOG_URL L"https://github.com/pjampjam/HLMC-Reborn/releases/latest/download/app-release.txt"
