#include "shortcut_policy.h"
#include <iostream>
#include <string>
namespace fs=std::filesystem;
static void check(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
int main(int argc,char** argv){
    try{
        if(argc!=2)throw std::runtime_error("Provide an unused isolated test directory.");
        fs::path root=fs::absolute(argv[1]);check(!fs::exists(root),"Test directory must be unused.");
        auto fresh=root/"fresh";fs::create_directories(fresh);int calls=0;
        auto create=[&](){++calls;std::ofstream(fresh/"Desktop.lnk")<<"desktop";std::ofstream(fresh/"Start.lnk")<<"start";};
        initial_shortcuts(fresh,false,create);
        check(calls==1&&fs::exists(fresh/"Desktop.lnk")&&fs::exists(fresh/"Start.lnk"),"First install did not create both shortcuts.");
        fs::remove(fresh/"Desktop.lnk");std::ofstream(fresh/"Start.lnk")<<"personal shortcut";
        initial_shortcuts(fresh,true,create);
        check(calls==1&&!fs::exists(fresh/"Desktop.lnk"),"Deleted Desktop shortcut was recreated.");
        std::ifstream current(fresh/"Start.lnk");std::string content;std::getline(current,content);current.close();check(content=="personal shortcut","Remaining shortcut was overwritten.");
        fs::remove(fresh/"Start.lnk");initial_shortcuts(fresh,true,create);
        check(calls==1&&!fs::exists(fresh/"Start.lnk"),"Deleted Start menu shortcut was recreated.");
        initial_shortcuts(fresh,false,create);check(calls==1,"A downloaded installer recreated removed shortcuts.");
        auto legacy=root/"legacy";fs::create_directories(legacy);int legacy_calls=0;
        initial_shortcuts(legacy,true,[&](){++legacy_calls;});
        initial_shortcuts(legacy,false,[&](){++legacy_calls;});
        check(legacy_calls==0&&fs::exists(legacy/"shortcuts-initialized.txt"),"Existing install migration recreated shortcuts.");
        std::cout<<"PASS: first install, deleted Desktop, deleted Start menu, preserved shortcut, downloaded installer, legacy migration.\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
