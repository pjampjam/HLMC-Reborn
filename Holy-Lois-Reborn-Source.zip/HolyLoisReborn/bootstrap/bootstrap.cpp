#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <shlobj.h>
#include <shellapi.h>
#include <shobjidl.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <atomic>
#include <array>
#include "public_key.h"
#include "channel.h"
#include "shortcut_policy.h"
#ifndef CATALOG_URL
#define CATALOG_URL L""
#endif
namespace fs = std::filesystem;
static HBRUSH background = CreateSolidBrush(RGB(32,33,31));
static HWND label; static std::atomic<bool> cancelled=false; static bool busy=true;
struct Internet { HINTERNET h; ~Internet(){if(h)WinHttpCloseHandle(h);} };
static void status(HWND window, const wchar_t* text){PostMessageW(window,WM_APP+1,0,reinterpret_cast<LPARAM>(new std::wstring(text)));}
static void reject_links(const fs::path& path){for(auto p=path; !p.empty(); p=p.parent_path()){DWORD a=GetFileAttributesW(p.c_str());if(a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_REPARSE_POINT))throw std::runtime_error("Linked installation folders are not supported.");if(p==p.parent_path())break;}}
static std::vector<unsigned char> read(const fs::path& p,size_t limit){std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error("A release file is missing.");f.seekg(0,std::ios::end);auto n=f.tellg();if(n<0||static_cast<unsigned long long>(n)>limit)throw std::runtime_error("Release file is too large.");f.seekg(0);std::vector<unsigned char>b(static_cast<size_t>(n));f.read(reinterpret_cast<char*>(b.data()),n);if(!f)throw std::runtime_error("Release file could not be read.");return b;}
static bool signature_ok(const std::vector<unsigned char>& bytes,const std::vector<unsigned char>& signature){
    CERT_PUBLIC_KEY_INFO* info=nullptr;DWORD n=0; BCRYPT_KEY_HANDLE key=nullptr;
    if(!CryptDecodeObjectEx(X509_ASN_ENCODING,X509_PUBLIC_KEY_INFO,public_key,sizeof(public_key),CRYPT_DECODE_ALLOC_FLAG,nullptr,&info,&n))return false;
    bool imported=CryptImportPublicKeyInfoEx2(X509_ASN_ENCODING,info,0,nullptr,&key);LocalFree(info);if(!imported)return false;
    BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;unsigned char digest[32];
    bool ok=BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0 && BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)>=0 && BCryptHashData(hash,const_cast<PUCHAR>(bytes.data()),static_cast<ULONG>(bytes.size()),0)>=0 && BCryptFinishHash(hash,digest,32,0)>=0;
    BCRYPT_PSS_PADDING_INFO padding{BCRYPT_SHA256_ALGORITHM,32};
    ok=ok&&BCryptVerifySignature(key,&padding,digest,32,const_cast<PUCHAR>(signature.data()),static_cast<ULONG>(signature.size()),BCRYPT_PAD_PSS)>=0;
    if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);BCryptDestroyKey(key);return ok;
}
static std::string hash_file(const fs::path& path){
    BCRYPT_ALG_HANDLE alg=nullptr; BCRYPT_HASH_HANDLE hash=nullptr;unsigned char digest[32];
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0||BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)<0)throw std::runtime_error("Checksum provider unavailable.");
    std::ifstream f(path,std::ios::binary);char b[65536];bool ok=static_cast<bool>(f);
    while(f.read(b,sizeof(b))||f.gcount())if(BCryptHashData(hash,reinterpret_cast<PUCHAR>(b),static_cast<ULONG>(f.gcount()),0)<0)ok=false;
    ok=ok&&!f.bad()&&BCryptFinishHash(hash,digest,32,0)>=0;BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(alg,0);if(!ok)throw std::runtime_error("Checksum failed.");
    const char* hex="0123456789abcdef";std::string out;for(auto c:digest){out+=hex[c>>4];out+=hex[c&15];}return out;
}
static std::wstring wide(const std::string& value){return std::wstring(value.begin(),value.end());}
struct Catalog{std::string version,url,hash; unsigned long long size;};
static Catalog parse(const std::vector<unsigned char>& b,const std::vector<unsigned char>& sig){
    if(!signature_ok(b,sig))throw std::runtime_error("Release signature failed. No downloaded application was run.");
    std::string text(b.begin(),b.end());if(text.find('\r')!=std::string::npos||text.find('\0')!=std::string::npos)throw std::runtime_error("Invalid release catalog.");
    std::istringstream s(text);std::string magic,size,extra;Catalog c{};
    if(!std::getline(s,magic)||!std::getline(s,c.version)||!std::getline(s,c.url)||!std::getline(s,c.hash)||!std::getline(s,size)||std::getline(s,extra)||magic!="holylois-app-v1")throw std::runtime_error("Invalid release catalog.");
    if(c.version.empty()||c.version.size()>30||c.version.front()=='.'||c.version.back()=='.'||c.version.find("..")!=std::string::npos||c.version.find_first_not_of("0123456789.")!=std::string::npos||c.hash.size()!=64||c.hash.find_first_not_of("0123456789abcdef")!=std::string::npos||size.empty()||size.size()>10||size.find_first_not_of("0123456789")!=std::string::npos)throw std::runtime_error("Invalid release identity.");
    if(c.url.rfind("https://github.com/",0)!=0||c.url.find("/releases/download/")==std::string::npos||c.url.size()>500||c.url.substr(c.url.size()-4)!=".exe"||c.url.find_first_of("\" <>\t")!=std::string::npos)throw std::runtime_error("Invalid application download URL.");
    c.size=std::stoull(size);if(c.size<1024||c.size>250ULL*1024*1024)throw std::runtime_error("Application size outside the permitted range.");return c;
}
// HTTPS only; metadata is bounded and the executable is streamed to a staging file.
static std::vector<unsigned char> fetch(const std::wstring& url,size_t limit,const fs::path* file=nullptr){
    wchar_t host[256],path[2048];URL_COMPONENTS u{sizeof(u)};u.lpszHostName=host;u.dwHostNameLength=256;u.lpszUrlPath=path;u.dwUrlPathLength=2048;
    if(!WinHttpCrackUrl(url.c_str(),0,0,&u)||u.nScheme!=INTERNET_SCHEME_HTTPS||u.nPort!=443)throw std::runtime_error("Only HTTPS release downloads are allowed.");
    Internet session{WinHttpOpen(L"HolyLoisReborn/0.1",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0)};
    if(!session.h)throw std::runtime_error("Network connection unavailable.");WinHttpSetTimeouts(session.h,15000,15000,15000,30000);
    Internet connection{WinHttpConnect(session.h,std::wstring(host,u.dwHostNameLength).c_str(),443,0)};
    Internet request{WinHttpOpenRequest(connection.h,L"GET",std::wstring(path,u.dwUrlPathLength).c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE)};
    DWORD redirect=WINHTTP_OPTION_REDIRECT_POLICY_DISALLOW_HTTPS_TO_HTTP;WinHttpSetOption(request.h,WINHTTP_OPTION_REDIRECT_POLICY,&redirect,sizeof(redirect));
    if(!request.h||!WinHttpSendRequest(request.h,WINHTTP_NO_ADDITIONAL_HEADERS,0,nullptr,0,0,0)||!WinHttpReceiveResponse(request.h,nullptr))throw std::runtime_error("Release download failed. Check your internet connection and retry.");
    DWORD code=0,codeSize=sizeof(code);if(!WinHttpQueryHeaders(request.h,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&code,&codeSize,WINHTTP_NO_HEADER_INDEX)||code!=200)throw std::runtime_error("The release is unavailable. No installed files were changed.");
    std::ofstream output;if(file){reject_links(*file);output.open(*file,std::ios::binary|std::ios::trunc);if(!output)throw std::runtime_error("Could not create the staged download.");}
    std::vector<unsigned char> result;unsigned char buffer[65536];DWORD n;size_t count=0;
    while(true){if(cancelled)throw std::runtime_error("Download cancelled.");if(!WinHttpReadData(request.h,buffer,sizeof(buffer),&n))throw std::runtime_error("Download interrupted. Retry to finish setup.");if(!n)break;count+=n;if(count>limit)throw std::runtime_error("Download exceeded the approved size.");if(file)output.write(reinterpret_cast<char*>(buffer),n);else result.insert(result.end(),buffer,buffer+n);}
    if(file){output.flush();if(!output)throw std::runtime_error("Could not finish the staged download.");}return result;
}
static void shortcut(const fs::path& target){
    if(FAILED(CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED)))return;
    IShellLinkW* link=nullptr;if(SUCCEEDED(CoCreateInstance(CLSID_ShellLink,nullptr,CLSCTX_INPROC_SERVER,IID_IShellLinkW,reinterpret_cast<void**>(&link)))){
        link->SetPath(target.c_str());link->SetIconLocation(target.c_str(),0);link->SetDescription(L"Holy Lois: Reborn - check for updates and play");link->SetWorkingDirectory(target.parent_path().c_str());
        IPersistFile* persist=nullptr;if(SUCCEEDED(link->QueryInterface(IID_IPersistFile,reinterpret_cast<void**>(&persist)))){
            for(const KNOWNFOLDERID* folder : {&FOLDERID_Desktop,&FOLDERID_Programs}){
                PWSTR location=nullptr;if(SUCCEEDED(SHGetKnownFolderPath(*folder,0,nullptr,&location))){
                    fs::path p=fs::path(location)/L"Holy Lois Reborn.lnk";reject_links(p);
                    if(FAILED(persist->Save(p.c_str(),TRUE))){CoTaskMemFree(location);persist->Release();link->Release();CoUninitialize();throw std::runtime_error("Could not create the Holy Lois shortcut.");}
                    SHChangeNotify(SHCNE_UPDATEITEM,SHCNF_PATHW,p.c_str(),nullptr);CoTaskMemFree(location);
                }
            }
            persist->Release();}link->Release();}CoUninitialize();
}
static void launch(const fs::path& exe,const std::wstring& args){std::wstring cmd=L"\""+exe.wstring()+L"\""+args;STARTUPINFOW si{sizeof(si)};PROCESS_INFORMATION pi{};if(!CreateProcessW(exe.c_str(),cmd.data(),nullptr,nullptr,FALSE,0,nullptr,exe.parent_path().c_str(),&si,&pi))throw std::runtime_error("Verified launcher could not start.");CloseHandle(pi.hThread);CloseHandle(pi.hProcess);}
static fs::path self_path(){wchar_t name[32768];DWORD n=GetModuleFileNameW(nullptr,name,32768);if(!n||n>=32768)throw std::runtime_error("Installer path unavailable.");return fs::path(std::wstring(name,n));}
static void run(HWND window,bool preview){
    auto self=self_path();Catalog catalog{};fs::path app;
    if(preview){status(window,L"Verifying the local development build…");catalog=parse(read(self.parent_path()/L"app-release.txt",65536),read(self.parent_path()/L"app-release.txt.sig",512));app=self.parent_path()/L"HolyLoisReborn.exe";}
    else{
        if(std::wstring(CATALOG_URL).empty())throw std::runtime_error("This is a development installer. Its online release channel is not published yet. Use the local preview package to review the app.");
        status(window,L"Checking the signed Holy Lois release…");auto bytes=fetch(CATALOG_URL,65536);auto sig=fetch(std::wstring(CATALOG_URL)+L".sig",512);catalog=parse(bytes,sig);
        PWSTR local=nullptr;if(FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&local)))throw std::runtime_error("Your app data folder is unavailable.");
        fs::path base=fs::path(local)/L"HolyLoisReborn";CoTaskMemFree(local);reject_links(base);fs::create_directories(base/L"app"/wide(catalog.version));
        auto channel=base/L"last-app-release.txt";
        if(fs::exists(channel)&&fs::exists(base/L"last-app-release.txt.sig")){
            auto previous=parse(read(channel,65536),read(base/L"last-app-release.txt.sig",512));
            auto numbers=[](const std::string& v){std::array<unsigned long,4> r{};std::istringstream s(v);std::string n;size_t i=0;while(std::getline(s,n,'.')){if(i>=4||n.size()>6)throw std::runtime_error("Invalid app version.");r[i++]=std::stoul(n);}return r;};
            if(numbers(catalog.version)<numbers(previous.version))throw std::runtime_error("An older app release was offered. Update was refused.");}
        app=base/L"app"/wide(catalog.version)/L"HolyLoisReborn.exe";reject_links(app);
        if(!fs::exists(app)||fs::file_size(app)!=catalog.size||hash_file(app)!=catalog.hash){status(window,L"Downloading the launcher - no .NET install needed…");auto partial=app;partial+=L".part";try{fetch(wide(catalog.url),catalog.size,&partial);if(fs::file_size(partial)!=catalog.size||hash_file(partial)!=catalog.hash)throw std::runtime_error("Application checksum failed. Nothing was run.");if(!MoveFileExW(partial.c_str(),app.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))throw std::runtime_error("Could not install the verified launcher.");}catch(...){fs::remove(partial);throw;}}
        auto installed=base/L"HolyLoisSetup.exe";reject_links(installed);
        const bool existing_installation=fs::exists(installed)||fs::exists(channel)||fs::exists(base/L"data"/L"launcher-settings.json");
        reject_links(base/L"shortcuts-initialized.txt");
        if(self!=installed)fs::copy_file(self,installed,fs::copy_options::overwrite_existing);
        {std::ofstream f(channel,std::ios::binary);f.write(reinterpret_cast<char*>(bytes.data()),bytes.size());}{std::ofstream f(base/L"last-app-release.txt.sig",std::ios::binary);f.write(reinterpret_cast<char*>(sig.data()),sig.size());}
        initial_shortcuts(base,existing_installation,[&](){shortcut(installed);});
    }
    if(!fs::exists(app)||fs::file_size(app)!=catalog.size||hash_file(app)!=catalog.hash)throw std::runtime_error("Local application checksum failed. Nothing was run.");
    if(cancelled)throw std::runtime_error("Setup cancelled.");
    launch(app,preview?L" --data-dir \""+(self.parent_path()/L"preview-data").wstring()+L"\"":L"");
}
static LRESULT CALLBACK procedure(HWND w,UINT m,WPARAM wp,LPARAM lp){
    if(m==WM_CTLCOLORSTATIC){auto dc=reinterpret_cast<HDC>(wp);SetTextColor(dc,RGB(243,243,238));SetBkColor(dc,RGB(32,33,31));return reinterpret_cast<LRESULT>(background);}
    if(m==WM_PAINT){PAINTSTRUCT ps{};auto dc=BeginPaint(w,&ps);RECT area{};GetClientRect(w,&area);FillRect(dc,&area,background);RECT line{28,area.bottom-22,area.right-28,area.bottom-19};auto gold=CreateSolidBrush(RGB(245,239,66));FillRect(dc,&line,gold);DeleteObject(gold);EndPaint(w,&ps);return 0;}
    if(m==WM_APP+1){auto s=reinterpret_cast<std::wstring*>(lp);SetWindowTextW(label,s->c_str());delete s;return 0;}
    if(m==WM_APP+2){busy=false;auto error=reinterpret_cast<std::wstring*>(lp);if(error){MessageBoxW(w,error->c_str(),L"Holy Lois: Reborn",MB_OK|MB_ICONINFORMATION);delete error;}DestroyWindow(w);return 0;}
    if(m==WM_CLOSE){if(busy){cancelled=true;SetWindowTextW(label,L"Cancelling safely…");return 0;}DestroyWindow(w);return 0;}
    if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int){
    int argc;LPWSTR* argv=CommandLineToArgvW(GetCommandLineW(),&argc);bool preview=argc==2&&std::wstring(argv[1])==L"--local-preview";
    if(argc==4&&std::wstring(argv[1])==L"--verify-local"){
        try{fs::path cat=argv[2],exe=argv[3];auto c=parse(read(cat,65536),read(fs::path(cat.wstring()+L".sig"),512));bool ok=fs::file_size(exe)==c.size&&hash_file(exe)==c.hash;LocalFree(argv);return ok?0:3;}catch(...){LocalFree(argv);return 2;}}
    LocalFree(argv);WNDCLASSW cls{};cls.lpfnWndProc=procedure;cls.hInstance=instance;cls.lpszClassName=L"HolyLoisSetup";cls.hCursor=LoadCursor(nullptr,IDC_ARROW);cls.hbrBackground=background;cls.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(101));RegisterClassW(&cls);
    RECT work{};SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);int width=540,height=210;
    HWND window=CreateWindowExW(0,cls.lpszClassName,L"Holy Lois: Reborn",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,work.left+(work.right-work.left-width)/2,work.top+(work.bottom-work.top-height)/2,width,height,nullptr,nullptr,instance,nullptr);
    BOOL dark=TRUE;DwmSetWindowAttribute(window,20,&dark,sizeof(dark));COLORREF caption=RGB(16,17,16),text=RGB(243,243,238);DwmSetWindowAttribute(window,35,&caption,sizeof(caption));DwmSetWindowAttribute(window,36,&text,sizeof(text));
    auto title=CreateWindowW(L"STATIC",L"HOLY LOIS: REBORN",WS_CHILD|WS_VISIBLE|SS_CENTER,28,24,468,36,window,nullptr,instance,nullptr);
    label=CreateWindowW(L"STATIC",L"Preparing your launcher…",WS_CHILD|WS_VISIBLE|SS_CENTER,28,74,468,54,window,nullptr,instance,nullptr);
    HFONT font=CreateFontW(22,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");SendMessageW(title,WM_SETFONT,reinterpret_cast<WPARAM>(font),TRUE);SendMessageW(label,WM_SETFONT,reinterpret_cast<WPARAM>(GetStockObject(DEFAULT_GUI_FONT)),TRUE);
    ShowWindow(window,SW_SHOW);UpdateWindow(window);
    std::thread worker([=](){std::wstring* error=nullptr;try{run(window,preview);}catch(const std::exception& e){error=new std::wstring(wide(e.what()));}PostMessageW(window,WM_APP+2,0,reinterpret_cast<LPARAM>(error));});
    MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}worker.join();DeleteObject(font);DeleteObject(background);return 0;
}
