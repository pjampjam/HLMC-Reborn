#pragma once
#include <filesystem>
#include <fstream>
#include <stdexcept>

// A persistent install marker records that shortcut setup was already considered.
// Missing shortcuts after that point represent the user's choice.
template<class CreateShortcuts>
static void initial_shortcuts(const std::filesystem::path& base, bool existing_installation, CreateShortcuts create) {
    const auto marker = base / L"shortcuts-initialized.txt";
    if (std::filesystem::exists(marker)) return;
    if (!existing_installation) create();
    std::ofstream state(marker, std::ios::binary | std::ios::trunc);
    state << "Holy Lois shortcut setup completed. Deleted shortcuts stay deleted.\n";
    state.flush();
    if (!state) throw std::runtime_error("Could not remember shortcut setup.");
}
