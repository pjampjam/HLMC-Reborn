param([string]$CatalogUrl = '')
$ErrorActionPreference = 'Stop'
if ($CatalogUrl -and $CatalogUrl -notmatch '^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/releases/latest/download/app-release\.txt$') { throw 'Use the exact GitHub Releases stable catalog URL.' }
$compiler = Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot '..\..\toolchain') -Directory -Filter 'llvm-mingw*' | Select-Object -First 1
if (!$compiler) { throw 'Install a trusted llvm-mingw compiler and point this script to it.' }
$bin = Join-Path $compiler.FullName 'bin'
$der = [System.IO.File]::ReadAllBytes((Join-Path $PSScriptRoot '..\assets\release-public.der'))
$hex = ($der | ForEach-Object { '0x{0:x2}' -f $_ }) -join ','
Set-Content -LiteralPath (Join-Path $PSScriptRoot 'public_key.h') -Value "static const unsigned char public_key[] = {$hex};" -Encoding ascii
Set-Content -LiteralPath (Join-Path $PSScriptRoot 'channel.h') -Value ('#define CATALOG_URL L"' + $CatalogUrl + '"') -Encoding ascii
$publish = Join-Path $PSScriptRoot '..\publish\bootstrap'
New-Item -ItemType Directory -Path $publish -Force | Out-Null
Push-Location $PSScriptRoot
try {
    & (Join-Path $bin 'x86_64-w64-mingw32-windres.exe') bootstrap.rc -O coff -o (Join-Path $publish 'bootstrap.res')
    if ($LASTEXITCODE) { throw 'Resource compilation failed.' }
    & (Join-Path $bin 'x86_64-w64-mingw32-clang++.exe') bootstrap.cpp (Join-Path $publish 'bootstrap.res') -o (Join-Path $publish 'HolyLoisSetup.exe') -std=c++20 -Os -municode -mwindows -static -lwinhttp -lbcrypt -lcrypt32 -lshell32 -lole32 -luuid -ldwmapi '-Wl,--dynamicbase' '-Wl,--nxcompat' '-Wl,--high-entropy-va' '-Wl,--strip-all'
    if ($LASTEXITCODE) { throw 'Bootstrap compilation failed.' }
} finally { Pop-Location }
Get-Item -LiteralPath (Join-Path $publish 'HolyLoisSetup.exe') | Select-Object Name,Length
